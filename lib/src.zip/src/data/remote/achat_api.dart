

class AchatApi{
  // fonction pour annuler la transaction en attente


}