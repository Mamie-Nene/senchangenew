class AppSizes{
  //UPPERCASE to facilitate recognation of const variable
  static const double PAGE_PADDING = 16.0;
  static const double CARD_RADIUS = 16.0;
}